import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import JobGrid from "@/components/jobs/JobGrid";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />
      
      <main>
        <section className="rotate-[-0.0006278649760828659rad] bg-[rgba(249,248,247,1)] flex h-[586px] w-full text-white">
          <div className="min-w-60 w-full flex-1 shrink basis-[0%] max-md:max-w-full">
            <div className="flex min-h-[586px] w-full overflow-hidden px-14 max-md:max-w-full max-md:px-5">
              <div className="flex min-w-60 min-h-[401px] w-full items-center flex-1 shrink basis-[0%] py-[73px] max-md:max-w-full">
                <div className="self-stretch flex min-w-60 flex-col items-stretch my-auto rounded-[99px] max-md:max-w-full">
                  <div className="bg-[rgba(252,76,2,1)] gap-2 overflow-hidden text-base font-bold px-4 py-1.5 rounded-[99px] w-fit">
                    TRABALHE CONOSCO
                  </div>
                  <h1 className="text-[40px] text-black font-semibold leading-[48px] mt-8 max-md:max-w-full">
                    Confira nossas vagas<br />
                    disponíveis e faça parte <br />
                    da equipe que movimenta <br />o futuro do transporte!
                  </h1>
                </div>
              </div>
            </div>
          </div>
        </section>

        <JobGrid />

        <section className="flex min-h-[446px] w-full gap-5 justify-center flex-wrap pl-[52px] pr-[51px] pt-5 pb-[53px] max-md:max-w-full max-md:px-5">
          <div className="bg-[rgba(249,248,247,1)] flex min-w-60 min-h-[373px] flex-col overflow-hidden items-stretch text-base text-white font-semibold justify-center grow shrink w-64 px-8 py-[55px] rounded-xl max-md:px-5">
            <img
              loading="lazy"
              srcSet="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/762cbe6c5493db37e6a972e75436d1ae6dc9e58f12b5f1cf896141c388aa11a2?placeholderIfAbsent=true&width=100 100w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/762cbe6c5493db37e6a972e75436d1ae6dc9e58f12b5f1cf896141c388aa11a2?placeholderIfAbsent=true&width=200 200w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/762cbe6c5493db37e6a972e75436d1ae6dc9e58f12b5f1cf896141c388aa11a2?placeholderIfAbsent=true&width=400 400w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/762cbe6c5493db37e6a972e75436d1ae6dc9e58f12b5f1cf896141c388aa11a2?placeholderIfAbsent=true&width=800 800w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/762cbe6c5493db37e6a972e75436d1ae6dc9e58f12b5f1cf896141c388aa11a2?placeholderIfAbsent=true&width=1200 1200w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/762cbe6c5493db37e6a972e75436d1ae6dc9e58f12b5f1cf896141c388aa11a2?placeholderIfAbsent=true&width=1600 1600w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/762cbe6c5493db37e6a972e75436d1ae6dc9e58f12b5f1cf896141c388aa11a2?placeholderIfAbsent=true&width=2000 2000w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/762cbe6c5493db37e6a972e75436d1ae6dc9e58f12b5f1cf896141c388aa11a2?placeholderIfAbsent=true"
              className="aspect-[1.16] object-contain w-[197px] self-center max-w-full"
              alt="Resume"
            />
            <button className="self-stretch bg-[rgba(252,76,2,1)] min-h-[77px] w-full gap-2 overflow-hidden mt-4 px-[18px] py-[29px] rounded-[14px]">
              CADASTRE SEU CURRÍCULO
            </button>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;