const Footer = () => {
  return (
    <footer className="rotate-[0.009315325604727979rad] w-full max-md:max-w-full">
      <div className="bg-[rgba(245,243,240,1)] flex w-full gap-[40px_65px] overflow-hidden justify-between flex-wrap p-20 max-md:max-w-full max-md:px-5">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/81dd2fde820281c989e49bcd46f8058169176db6a8a1879f4e9574931efc1242?placeholderIfAbsent=true"
          className="aspect-[4.2] object-contain w-[122px] shrink-0"
          alt="Logo"
        />
        <div className="flex min-w-60 gap-6 text-sm leading-none flex-wrap max-md:max-w-full">
          <div className="overflow-hidden w-[202px]">
            <h3 className="text-[rgba(154,144,129,1)] font-bold uppercase">
              Contato
            </h3>
            <nav className="w-full text-[rgba(29,29,29,1)] font-medium mt-4">
              <ul>
                <li className="mt-3">Atendimento</li>
                <li className="mt-3">Cotação</li>
                <li className="mt-3">Seja cliente</li>
                <li className="mt-3">Agregue seu veículo</li>
                <li className="mt-3">Trabalhe conosco</li>
              </ul>
            </nav>
          </div>
          {/* Similar sections for AGEX, Conta, and BLOG */}
        </div>
        <div className="flex flex-col">
          <div className="flex gap-6">
            <div className="flex items-center gap-3 w-10">
              <img
                loading="lazy"
                src="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/64cb443ac2ffcec257d0c6d8403d032841e9e60cca8263334f572aad79dce2e2?placeholderIfAbsent=true"
                className="aspect-[0.98] object-contain w-10 self-stretch my-auto rounded-xl"
                alt="Social Media"
              />
            </div>
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/1ef9833c3229c063add4a461474a0c26c3ba43922d3f78eb30bcb334d5878b80?placeholderIfAbsent=true"
              className="aspect-[1] object-contain w-10 shrink-0 rounded-xl"
              alt="Social Media"
            />
          </div>
          <div className="bg-white shadow-[0px_1px_4px_rgba(0,0,0,0.1)] flex max-w-full w-[221px] items-stretch gap-[7px] overflow-hidden mt-6 px-2.5 py-3 rounded-lg">
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/f74b3848517f343b1c1ca2a769b63af0aa29588b80b7b31679c6855c01e1494b?placeholderIfAbsent=true"
              className="aspect-[5.92] object-contain w-40 max-w-full"
              alt="App Store"
            />
            <img
              loading="lazy"
              srcSet="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/5912e28814e6af96acc559b9a8ec2473ee8083870df1d41e7d1f5f4b7d0cbf9a?placeholderIfAbsent=true&width=100 100w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/5912e28814e6af96acc559b9a8ec2473ee8083870df1d41e7d1f5f4b7d0cbf9a?placeholderIfAbsent=true&width=200 200w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/5912e28814e6af96acc559b9a8ec2473ee8083870df1d41e7d1f5f4b7d0cbf9a?placeholderIfAbsent=true&width=400 400w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/5912e28814e6af96acc559b9a8ec2473ee8083870df1d41e7d1f5f4b7d0cbf9a?placeholderIfAbsent=true&width=800 800w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/5912e28814e6af96acc559b9a8ec2473ee8083870df1d41e7d1f5f4b7d0cbf9a?placeholderIfAbsent=true&width=1200 1200w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/5912e28814e6af96acc559b9a8ec2473ee8083870df1d41e7d1f5f4b7d0cbf9a?placeholderIfAbsent=true&width=1600 1600w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/5912e28814e6af96acc559b9a8ec2473ee8083870df1d41e7d1f5f4b7d0cbf9a?placeholderIfAbsent=true&width=2000 2000w, https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/5912e28814e6af96acc559b9a8ec2473ee8083870df1d41e7d1f5f4b7d0cbf9a?placeholderIfAbsent=true"
              className="aspect-[0.97] object-contain w-[34px] shrink-0 rounded-[56px]"
              alt="QR Code"
            />
          </div>
        </div>
      </div>
      <div className="bg-[rgba(245,243,240,1)] flex w-full gap-[40px_100px] overflow-hidden text-sm font-medium leading-none justify-between flex-wrap px-20 py-10 max-md:max-w-full max-md:px-5">
        <div className="flex min-w-60 items-center gap-[40px_56px] flex-wrap max-md:max-w-full">
          <span className="text-[rgba(128,117,102,1)]">
            © 2024 Agex Transportes LTDA
          </span>
          <nav className="self-stretch flex min-w-60 items-center gap-8 text-[rgba(29,29,29,1)] my-auto">
            <a href="#" className="hover:text-gray-600">Seja Cliente</a>
            <a href="#" className="hover:text-gray-600">Agregue seu veículo</a>
            <a href="#" className="hover:text-gray-600">Trabalhe conosco</a>
          </nav>
        </div>
        <div className="self-stretch border min-h-[26px] gap-2 text-[rgba(29,29,29,1)] px-[11px] py-0.5 rounded-[38px] border-[rgba(0,0,0,0.1)] border-solid">
          Desenvolvido por Hyerdev
        </div>
      </div>
    </footer>
  );
};

export default Footer;