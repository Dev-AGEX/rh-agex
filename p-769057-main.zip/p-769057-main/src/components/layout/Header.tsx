import { Button } from "@/components/ui/button";

const Header = () => {
  return (
    <header className="bg-white shadow-[0px_4px_4px_rgba(0,0,0,0.08)] flex min-h-[72px] w-full items-center gap-[40px_100px] overflow-hidden text-base font-semibold justify-between flex-wrap px-14 py-4 max-md:max-w-full max-md:px-5">
      <div className="self-stretch flex min-w-60 items-center gap-6 text-black flex-wrap my-auto max-md:max-w-full">
        <img
          loading="lazy"
          src="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/0edea245bfef229a48677eed8b58f84226ba8d899d02f0f33a784e0ebd5d5aa7?placeholderIfAbsent=true"
          className="aspect-[4.33] object-contain w-[121px] self-stretch shrink-0 my-auto"
          alt="Company Logo"
        />
        <nav className="self-stretch flex min-w-60 items-center justify-center my-auto max-md:max-w-full">
          <Button variant="ghost" className="flex items-center gap-2">
            Empresa
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/738833c137fa233b5eadfd9232322c93c3a6e1bafe963578eadde6e664842c54?placeholderIfAbsent=true"
              className="aspect-[1] object-contain w-3"
              alt="Dropdown"
            />
          </Button>
          <Button variant="ghost">Seja cliente</Button>
          <Button variant="ghost">Fale conosco</Button>
          <Button variant="ghost">Blog</Button>
        </nav>
      </div>
      <div className="self-stretch flex gap-2 text-white my-auto">
        <Button className="bg-[rgba(252,76,2,1)] flex items-center gap-2">
          Criar conta / Login
          <img
            loading="lazy"
            src="https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/9268b7cfdc89d8651b8462ff9322ab4043eaf2e549343355670e03a6c599174b?placeholderIfAbsent=true"
            className="aspect-[1] object-contain w-6"
            alt="Login"
          />
        </Button>
      </div>
    </header>
  );
};

export default Header;