import JobCard from "./JobCard";

const JobGrid = () => {
  const jobs = [
    {
      title: "CONFERENTE DE CARGA",
      location: "MARINGA",
      imageUrl: "https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/126a1a2c3881f3ee8545b207d8304e586ab39e6ca5c9dbd37005234c6def78c0?placeholderIfAbsent=true"
    },
    {
      title: "CONFERENTE DE CARGAS",
      location: "CURITIBA",
      imageUrl: "https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/126a1a2c3881f3ee8545b207d8304e586ab39e6ca5c9dbd37005234c6def78c0?placeholderIfAbsent=true"
    },
    {
      title: "CONFERENTE DE CARGA",
      location: "CASCAVEL",
      imageUrl: "https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/126a1a2c3881f3ee8545b207d8304e586ab39e6ca5c9dbd37005234c6def78c0?placeholderIfAbsent=true"
    },
    {
      title: "CONFERENTE DE CARGA",
      location: "LONDRINA",
      imageUrl: "https://cdn.builder.io/api/v1/image/assets/61f34d37a0dd4f1491cb789f64379db9/126a1a2c3881f3ee8545b207d8304e586ab39e6ca5c9dbd37005234c6def78c0?placeholderIfAbsent=true"
    }
  ];

  return (
    <section className="flex min-h-[446px] w-full gap-5 justify-center flex-wrap pt-5 pb-[53px] px-10 max-md:max-w-full max-md:px-5">
      {jobs.map((job, index) => (
        <JobCard
          key={index}
          title={job.title}
          location={job.location}
          imageUrl={job.imageUrl}
        />
      ))}
    </section>
  );
};

export default JobGrid;