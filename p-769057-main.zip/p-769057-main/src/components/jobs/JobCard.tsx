interface JobCardProps {
  title: string;
  location: string;
  imageUrl: string;
}

const JobCard = ({ title, location, imageUrl }: JobCardProps) => {
  return (
    <div className="min-w-60 overflow-hidden grow shrink w-[274px] rounded-2xl">
      <div className="flex flex-col relative aspect-[0.92] w-full items-stretch pt-[152px] pb-6 px-[27px] max-md:pt-[100px] max-md:px-5">
        <img
          loading="lazy"
          src={imageUrl}
          className="absolute h-full w-full object-cover inset-0"
          alt={title}
        />
        <div className="relative text-white text-2xl font-bold leading-8 text-center">
          {title}
          <br />
          EM
          <br />
          {location}
        </div>
        <button className="relative self-center bg-[rgba(229,227,223,1)] min-h-10 gap-2 overflow-hidden text-base text-black font-semibold mt-[29px] px-6 py-[11px] rounded-[14px] max-md:px-5">
          VER DETALHES
        </button>
      </div>
    </div>
  );
};

export default JobCard;